 <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Admin A</span>
                                <img class="img-profile rounded-circle"
                                    src="img/undraw_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Settings
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->
<!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        \
                        <h1 class="h3 mb-0 text-gray-800">Selamat Datang di Sistem Pengambilan Keputusan Penerimaan Beasiswa</h1>
                    </div>

                            <!-- Illustrations -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Beasiswa</h6>
                                </div>

                                <div class="card-body">
                                    <p>Beasiswa merupakan penghasilan bagi yang menerima dan tujuan beasiswa adalah untuk membantu meringankan beban biaya pendidikkan siswa atau mahasiswa yang mendapatkan. Peraturan Pemerintah Nomor 48 tahun 2008 tentang Pendanaan Pendidikan, Bagian Kelima, Pasal 27 ayat (1), menyebutkan bahwa Pemerintah dan pemerintah daerah sesuai kewenangannya memberi bantuan biaya pendidikan atau beasiswa kepada peserta didik yang orang tua atau walinya tidak mampu membiayai pendidikannya. Pasal 27 ayat (2), menyebutkan bahwa Pemerintah dan pemerintah daerah sesuai dengan kewenangannya dapat memberi beasiswa kepada peserta didik yang berprestasi. Pembagaian beasiswa dilakukan oleh beberapa lembaga untuk membantu seseorang yang kurang mampu ataupun berprestasi selama menempuh studinya. Perguruan Tinggi akan memberikan beasiswa kepada mahasiswa setiap semester. Hal ini tentu dengan tujuan untuk meringankan beban biaya pendidikan mahasiswa. Dengan kreteria sebagai berikut: IPK, penghasilan orang tua, tanggungan orang tua, semester.</p>
                                    <p class="mb-0">Sasaran beasiswa adalah untuk Mahasiswa berprestasi (baik pada bidang akademik/kurikuler, ko-kurikuler maupun ekstra kurikuler). Dan Mahasiswa dengan prestasi minimal yang orang tua/wali-nya tidak mampu membiayai pendidikannya.</p>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>