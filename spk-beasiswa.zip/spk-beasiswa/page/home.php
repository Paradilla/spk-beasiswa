<!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        \
                        <h1 class="h3 mb-0 text-gray-800">Beranda</h1>
                    </div>

                            <!-- Illustrations -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Beasiswa</h6>
                                </div>

                                <div class="card-body">
                                    <p>Beasiswa merupakan penghasilan bagi yang menerima dan tujuan beasiswa adalah untuk membantu meringankan beban biaya pendidikkan siswa atau mahasiswa yang mendapatkan. Peraturan Pemerintah Nomor 48 tahun 2008 tentang Pendanaan Pendidikan, Bagian Kelima, Pasal 27 ayat (1), menyebutkan bahwa Pemerintah dan pemerintah daerah sesuai kewenangannya memberi bantuan biaya pendidikan atau beasiswa kepada peserta didik yang orang tua atau walinya tidak mampu membiayai pendidikannya. Pasal 27 ayat (2), menyebutkan bahwa Pemerintah dan pemerintah daerah sesuai dengan kewenangannya dapat memberi beasiswa kepada peserta didik yang berprestasi. Pembagaian beasiswa dilakukan oleh beberapa lembaga untuk membantu seseorang yang kurang mampu ataupun berprestasi selama menempuh studinya. Perguruan Tinggi akan memberikan beasiswa kepada mahasiswa setiap semester. Hal ini tentu dengan tujuan untuk meringankan beban biaya pendidikan mahasiswa. Dengan kreteria sebagai berikut: IPK, penghasilan orang tua, tanggungan orang tua, semester.</p>
                                    <p class="mb-0">Sasaran beasiswa adalah untuk Mahasiswa berprestasi (baik pada bidang akademik/kurikuler, ko-kurikuler maupun ekstra kurikuler). Dan Mahasiswa dengan prestasi minimal yang orang tua/wali-nya tidak mampu membiayai pendidikannya.</p>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>